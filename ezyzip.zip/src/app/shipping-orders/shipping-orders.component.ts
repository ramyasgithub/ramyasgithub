import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-orders',
  templateUrl: './shipping-orders.component.html',
  styleUrls: ['./shipping-orders.component.css']
})
export class ShippingOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
