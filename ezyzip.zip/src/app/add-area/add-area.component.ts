import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-area',
  templateUrl: './add-area.component.html',
  styleUrls: ['./add-area.component.css']
})
export class AddAreaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
