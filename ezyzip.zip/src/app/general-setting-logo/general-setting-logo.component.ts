import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-setting-logo',
  templateUrl: './general-setting-logo.component.html',
  styleUrls: ['./general-setting-logo.component.css']
})
export class GeneralSettingLogoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
