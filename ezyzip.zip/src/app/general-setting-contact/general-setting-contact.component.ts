import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-setting-contact',
  templateUrl: './general-setting-contact.component.html',
  styleUrls: ['./general-setting-contact.component.css']
})
export class GeneralSettingContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
