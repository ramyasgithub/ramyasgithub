import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-shop',
  templateUrl: './add-shop.component.html',
  styleUrls: ['./add-shop.component.css']
})
export class AddShopComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
