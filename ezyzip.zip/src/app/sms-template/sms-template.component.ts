import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-template',
  templateUrl: './sms-template.component.html',
  styleUrls: ['./sms-template.component.css']
})
export class SmsTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
