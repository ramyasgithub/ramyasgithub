import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-setting-analytics',
  templateUrl: './general-setting-analytics.component.html',
  styleUrls: ['./general-setting-analytics.component.css']
})
export class GeneralSettingAnalyticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
