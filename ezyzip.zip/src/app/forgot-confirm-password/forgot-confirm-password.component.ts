import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-confirm-password',
  templateUrl: './forgot-confirm-password.component.html',
  styleUrls: ['./forgot-confirm-password.component.css']
})
export class ForgotConfirmPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    console.log("localstorage,",localStorage.getItem('email'))
;  }

}
