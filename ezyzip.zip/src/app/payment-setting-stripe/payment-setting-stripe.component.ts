import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-setting-stripe',
  templateUrl: './payment-setting-stripe.component.html',
  styleUrls: ['./payment-setting-stripe.component.css']
})
export class PaymentSettingStripeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
