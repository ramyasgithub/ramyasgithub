import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-configure',
  templateUrl: './sms-configure.component.html',
  styleUrls: ['./sms-configure.component.css']
})
export class SmsConfigureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
