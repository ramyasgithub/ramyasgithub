import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-user-register',
  templateUrl: './sub-user-register.component.html',
  styleUrls: ['./sub-user-register.component.css']
})
export class SubUserRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
