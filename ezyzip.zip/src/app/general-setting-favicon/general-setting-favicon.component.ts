import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-setting-favicon',
  templateUrl: './general-setting-favicon.component.html',
  styleUrls: ['./general-setting-favicon.component.css']
})
export class GeneralSettingFaviconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
