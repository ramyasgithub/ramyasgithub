import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-unit-price',
  templateUrl: './product-unit-price.component.html',
  styleUrls: ['./product-unit-price.component.css']
})
export class ProductUnitPriceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
