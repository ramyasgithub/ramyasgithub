import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-setting',
  templateUrl: './payment-setting.component.html',
  styleUrls: ['./payment-setting.component.css']
})
export class PaymentSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
