import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-setting',
  templateUrl: './email-setting.component.html',
  styleUrls: ['./email-setting.component.css']
})
export class EmailSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
